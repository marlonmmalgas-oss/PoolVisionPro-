plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.poolvisionpro"
    compileSdk = 35
    defaultConfig { applicationId = "com.poolvisionpro"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0.0" }
}
