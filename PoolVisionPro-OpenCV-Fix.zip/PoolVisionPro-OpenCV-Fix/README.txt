POOL VISION PRO — OPENCV VISION ENGINE UPDATE

This patch replaces the existing colour-blob detector with an OpenCV pipeline:
- blue/cyan felt mask + morphology
- large central contour and 1.45–2.25 aspect-ratio checks to reject HUD panels
- inner playable-region crop
- Hough circle detection with radius bounds tied to table width
- duplicate suppression
- conservative white cue-ball confidence check
- suppresses the table/aim overlay if table geometry is not confidently found
- analysis downscaled to a maximum width of 900 px

FILES TO REPLACE IN CODESPACES:
1) app/build.gradle.kts
2) app/src/main/java/com/poolvisionpro/VisionEngine.kt

After replacing both files, run:
  git add app/build.gradle.kts app/src/main/java/com/poolvisionpro/VisionEngine.kt
  git commit -m "Replace heuristic detector with OpenCV table and ball vision"
  git push origin main

Then inspect GitHub Actions and install the new APK artifact.

IMPORTANT LIMITATIONS:
- This is a stronger first-stage detector, not a validated production computer-vision model.
- Hough circles may still need tuning against your exact game resolution, graphics settings and device.
- The current aiming guide is a provisional nearest-ball centre line. It does NOT infer the player's actual cue-stick direction or intended target.
- It does not implement spin, speed, collision restitution, pocket capture, or physically accurate multi-cushion trajectories.
- No manual four-corner calibration UI is included in this patch. Automatic detection is attempted first; if it fails, this version reports TABLE NOT LOCKED rather than drawing a false boundary.
- Build/runtime validation is still required on device.
