package com.poolvision.pro

import android.app.*
import android.content.*
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
 private val captureRequest=410
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val root=LinearLayout(this).apply { orientation=1; setPadding(28,36,28,24); setBackgroundColor(Color.rgb(9,18,28)) }
  fun label(s:String,size:Float=16f)=TextView(this).apply { text=s; textSize=size; setTextColor(Color.WHITE); setPadding(0,12,0,12) }
  root.addView(label("POOL VISION PRO",27f))
  root.addView(label("LIVE TABLE ANALYSIS  •  ANDROID"))
  root.addView(label("Automatic cue / ball tracking with predicted cue-ball and object-ball paths."))
  val overlay=Button(this).apply { text="1  •  ENABLE FLOATING OVERLAY"; setOnClickListener {
   if(!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
   else startService(Intent(this@MainActivity,AimOverlayService::class.java))
  } }
  root.addView(overlay)
  root.addView(Button(this).apply { text="2  •  START LIVE SCREEN TRACKING"; setOnClickListener {
   val m=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
   startActivityForResult(m.createScreenCaptureIntent(),captureRequest)
  }})
  root.addView(label("HOW TO USE",20f))
  root.addView(label("Open 8 Ball Pool, enable the overlay, then start screen tracking. Keep the game visible. Use the floating panel to toggle paths and calibration."))
  root.addView(label("Detection runs on-device. Screen frames are processed locally and are not uploaded."))
  setContentView(ScrollView(this).apply { addView(root) })
 }
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
  super.onActivityResult(requestCode,resultCode,data)
  if(requestCode==captureRequest && resultCode==RESULT_OK && data!=null) {
   val i=Intent(this,CaptureService::class.java).putExtra("code",resultCode).putExtra("data",data)
   if(Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i)
  }
 }
}
