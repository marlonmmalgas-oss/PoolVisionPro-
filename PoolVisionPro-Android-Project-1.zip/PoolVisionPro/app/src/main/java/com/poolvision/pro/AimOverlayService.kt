package com.poolvision.pro

import android.app.*
import android.content.*
import android.graphics.*
import android.os.*
import android.view.*
import android.widget.*

class AimOverlayService: Service() {
 private lateinit var wm:WindowManager
 private var panel:View?=null
 override fun onBind(i:Intent?)=null
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int { show(); return START_STICKY }
 private fun show() {
  if(panel!=null)return
  wm=getSystemService(WINDOW_SERVICE) as WindowManager
  val box=LinearLayout(this).apply { orientation=1; setPadding(12,8,12,8); setBackgroundColor(0xdd101c2b.toInt()) }
  val head=TextView(this).apply { text="POOL VISION  •  ≡"; textColor=Color.WHITE; textSize=14f; setPadding(8,8,8,8) }
  box.addView(head)
  val canvas=AimCanvas(this)
  box.addView(canvas,LinearLayout.LayoutParams(270,170))
  val row=LinearLayout(this)
  listOf("PATHS","BANK","−","＋","×").forEach { t-> row.addView(Button(this).apply { text=t; textSize=10f; setOnClickListener {
   when(t){"×"->stopSelf();"PATHS"->canvas.paths=!canvas.paths;"BANK"->canvas.bank=!canvas.bank;"＋"->canvas.length+=.2f;"−"->canvas.length=(canvas.length-.2f).coerceAtLeast(.4f)}
   canvas.invalidate()
  }},LinearLayout.LayoutParams(0,48,1f)) }
  box.addView(row)
  val type=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
  val p=WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=18;y=180 }
  var sx=0f;var sy=0f;var ox=0;var oy=0
  head.setOnTouchListener { _,e-> when(e.action){MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=p.x;oy=p.y;true};MotionEvent.ACTION_MOVE->{p.x=ox+(sx-e.rawX).toInt();p.y=oy+(e.rawY-sy).toInt();wm.updateViewLayout(box,p);true};else->true} }
  wm.addView(box,p);panel=box
 }
 override fun onDestroy(){ panel?.let{wm.removeView(it)};panel=null;super.onDestroy() }
}
class AimCanvas(c:android.content.Context):View(c) {
 var paths=true;var bank=false;var length=1f
 private val p=Paint(3)
 override fun onDraw(c:Canvas) {
  super.onDraw(c); val w=width.toFloat();val h=height.toFloat()
  p.color=0xff176c48.toInt();p.style=Paint.Style.FILL; c.drawRoundRect(3f,3f,w-3,h-3,12f,12f,p)
  p.color=0xffd8c39a.toInt();p.style=Paint.Style.STROKE;p.strokeWidth=3f;c.drawRoundRect(8f,8f,w-8,h-8,8f,8f,p)
  p.style=Paint.Style.FILL
  val cue=PointF(w*.25f,h*.66f);val obj=PointF(w*.72f,h*.34f)
  p.color=Color.WHITE;c.drawCircle(cue.x,cue.y,7f,p)
  p.color=0xffffcf42.toInt();c.drawCircle(obj.x,obj.y,7f,p)
  if(paths){p.style=Paint.Style.STROKE;p.strokeWidth=2.5f;p.color=0xff68e8ff.toInt();c.drawLine(cue.x,cue.y,cue.x+(obj.x-cue.x)*length,cue.y+(obj.y-cue.y)*length,p)
   p.color=0xffffd45c.toInt();c.drawLine(obj.x,obj.y,w-14f,h*.15f,p)
   p.color=Color.WHITE;p.pathEffect=DashPathEffect(floatArrayOf(7f,6f),0f);c.drawLine(cue.x,cue.y,cue.x-20,h*.2f,p);p.pathEffect=null
   if(bank){p.color=0xffff8b5c.toInt();c.drawLine(obj.x,obj.y,w*.88f,8f,p);c.drawLine(w*.88f,8f,w-12f,h*.72f,p)}
  }
  p.style=Paint.Style.FILL;p.color=Color.WHITE;p.textSize=12f;c.drawText("LIVE AIM PREVIEW",12f,h-12f,p)
 }
}
