package com.poolvision.pro

import android.app.*
import android.content.*
import android.graphics.Bitmap
import android.hardware.display.*
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import java.nio.ByteBuffer

class CaptureService:Service() {
 private var projection:MediaProjection?=null
 private var reader:ImageReader?=null
 private var display:VirtualDisplay?=null
 override fun onBind(i:Intent?)=null
 override fun onStartCommand(i:Intent?,flags:Int,startId:Int):Int {
  val channel="poolvision_capture"
  if(Build.VERSION.SDK_INT>=26){getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(channel,"Pool Vision tracking",NotificationManager.IMPORTANCE_LOW));startForeground(8,Notification.Builder(this,channel).setContentTitle("Pool Vision Pro").setContentText("On-device screen analysis active").setSmallIcon(android.R.drawable.ic_menu_camera).build())}
  val code=i?.getIntExtra("code",0)?:0
  val data=if(Build.VERSION.SDK_INT>=33)i?.getParcelableExtra("data",Intent::class.java) else @Suppress("DEPRECATION") (i?.getParcelableExtra("data") as? Intent)
  if(data!=null){val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager;projection=mgr.getMediaProjection(code,data);startFrames()}
  return START_NOT_STICKY
 }
 private fun startFrames(){
  val dm=resources.displayMetrics;reader=ImageReader.newInstance(dm.widthPixels,dm.heightPixels,android.graphics.PixelFormat.RGBA_8888,2)
  reader?.setOnImageAvailableListener({r->r.acquireLatestImage()?.use{image-> analyze(image)}},Handler(Looper.getMainLooper()))
  display=projection?.createVirtualDisplay("PoolVision",dm.widthPixels,dm.heightPixels,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader?.surface,null,null)
 }
 private fun analyze(image:Image) {
  // Frame pipeline hook: crop/scale and run ball segmentation here; frames remain on-device.
  val plane=image.planes.firstOrNull()?:return
  val buffer:ByteBuffer=plane.buffer
  if(!buffer.hasRemaining())return
  // Lightweight frame sampling keeps the capture loop responsive.
 }
 override fun onDestroy(){display?.release();reader?.close();projection?.stop();super.onDestroy()}
}
