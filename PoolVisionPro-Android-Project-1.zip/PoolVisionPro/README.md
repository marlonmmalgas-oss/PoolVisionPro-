# Pool Vision Pro
Fresh Android-only Kotlin project scaffold. Built through GitHub Actions; no cloud processing.

## Current foundation
- Android screen capture using user-approved MediaProjection.
- Movable floating overlay with touch-through disabled only for its own controls.
- Aim preview, path toggle, bank-shot toggle and line-length controls.
- On-device frame-processing hook for the computer-vision pipeline.

## Important
The current overlay preview is a UI prototype, not automatic ball/cue recognition. Real detection requires implementing and validating table calibration, cue segmentation, ball classification and tracking against actual 8 Ball Pool frames. The capture service currently samples frames but does not yet produce detected coordinates. Predicted cue-ball stop position also requires a speed/spin/friction model and cannot be inferred accurately from a static screenshot alone.
